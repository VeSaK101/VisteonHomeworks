#include "RegistryFactory.hpp"

#include <algorithm>

std::shared_ptr<Shape>
RegistryFactory::createShape(const std::string& type, const std::map<std::string, std::string> params) {
	auto maker = getShapeMaker(type);
	auto shape = maker();
	for (auto const& param : params) {
		shape->setParameter(param.first, param.second);
	}
	return shape;
}

void
RegistryFactory::registerShapeMaker(ShapeMaker maker, const std::string& name) {
	makers[name] = maker;	// This will throw away a possibly previously registered prototype with that name
}

ShapeMaker
RegistryFactory::getShapeMaker(const std::string& name) const {
	return makers.at(name);
}
