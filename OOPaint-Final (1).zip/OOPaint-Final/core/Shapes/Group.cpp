#include "Group.hpp"

#include <iostream>

void Group::setColor(const SDL_Color& color) {
	for (auto shape : shapes) {
		shape->setColor(color);
	}
}

void Group::moveBy(const Vector2D& delta) {
	for (auto shape : shapes) {
		shape->moveBy(delta);
	}
}

void Group::draw(SDL_Renderer* renderer) const {
	for (auto shape : shapes) {
		shape->draw(renderer);
	}
}

void Group::resize(double factor, const Coord2D& center) {
	for (auto shape : shapes) {
		shape->resize(factor, center);
	}
}

void Group::rotate(double angle, const Coord2D& center) {
	for (auto shape : shapes) {
		shape->rotate(angle, center);
	}
}

bool Group::containsCoordinates(const Coord2D& coord) const {
	for (auto shape : shapes) {
		if (shape->containsCoordinates(coord)) {
			return true;
		}
	}
	return false;
}

void Group::add(std::shared_ptr<Shape> shape) {
	shapes.insert(shape);
}

std::shared_ptr<Shape> Group::clone() const {
	return std::make_shared<Group>(*this);
}

Group::Group(const Group& other) {
	for (auto shape : other.shapes) {
		add(shape->clone());
	}
}

void Group::remove(std::shared_ptr<Shape> shape) {
	shapes.erase(shape);
}

void Group::setParameter(const std::string& name, const std::string& value) {
	std::clog << "CompositeShape: trying to set unknown parameter [" << name << "] to value [" << value << "]" << std::endl;
}
