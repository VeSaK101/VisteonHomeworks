#ifndef SRC_SHAPEREGISTRYFACTORY_HPP_
#define SRC_SHAPEREGISTRYFACTORY_HPP_

#include <map>

#include "Factory.hpp"
#include "ShapeRegistry.hpp"

class RegistryFactory: public Factory, public ShapeRegistry {
public:
	std::shared_ptr<Shape> createShape(const std::string& type, const std::map<std::string, std::string> params) override;
	void registerShapeMaker(ShapeMaker maker, const std::string& name) override;
	ShapeMaker getShapeMaker(const std::string& name) const override;

private:
	std::map<std::string, ShapeMaker> makers;
};

#endif /* SRC_SHAPEREGISTRYFACTORY_HPP_ */
