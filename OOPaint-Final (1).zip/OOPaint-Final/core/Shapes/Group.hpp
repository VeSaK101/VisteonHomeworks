#ifndef SHAPEGROUP_HPP
#define SHAPEGROUP_HPP

#include <memory>
#include <set>
#include "Shape.hpp"

class Group: public Shape {
public:
	Group() = default;
	Group(const Group& other);

	void setColor(const SDL_Color& color) override;
	void moveBy(const Vector2D& delta) override;
	void draw(SDL_Renderer* renderer) const override;
	void resize(double factor, const Coord2D& center) override;
	void rotate(double angle, const Coord2D& center) override;
	bool containsCoordinates(const Coord2D& coord) const override;
	std::shared_ptr<Shape> clone() const;

	// Specific for ShapeGroup
	void add(std::shared_ptr<Shape> shape);
	void remove(std::shared_ptr<Shape> shape);

private:
	std::set<std::shared_ptr<Shape>> shapes;
	void setParameter(const std::string& name, const std::string& value);
};

#endif /* SHAPEGROUP_HPP */
