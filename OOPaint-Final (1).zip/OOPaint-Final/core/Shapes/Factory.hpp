#ifndef SRC_SHAPEFACTORY_HPP_
#define SRC_SHAPEFACTORY_HPP_

#include <map>
#include <string>
#include <memory>
#include "Shape.hpp"

class Factory {
public:
	virtual ~Factory() = default;

	virtual std::shared_ptr<Shape> createShape(const std::string& type, const std::map<std::string, std::string> params) = 0;
};

#endif /* SRC_SHAPEFACTORY_HPP_ */
