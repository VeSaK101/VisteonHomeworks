#include "SimpleShape.hpp"

SimpleShape::SimpleShape()
: angle(0) {
}

void SimpleShape::setColor(const SDL_Color& color) {
	this->color = color;
}

const SDL_Color& SimpleShape::getColor() const {
	return color;
}

void SimpleShape::moveBy(const Vector2D& delta) {
	coordinates += delta;
}

void SimpleShape::resize(double factor, const Coord2D& center) {
	Vector2D radiusVector(center, coordinates);
	auto newRadiusVector = radiusVector * factor;
	coordinates = center + newRadiusVector;

	/*
	 * The following is known as Template Method Design Pattern
	 * The method is abstract here, and implemented (customized) in descendants
	 */
	resizeAroundOwnCenter(factor);
}

void SimpleShape::rotate(double angle, const Coord2D& center) {
	Vector2D radiusVector(center, coordinates);

	// See https://en.wikipedia.org/wiki/Rotation_matrix
	auto newRadiusVector = Coord2D(-radiusVector.x * cos(angle) - radiusVector.y * sin(angle),
									-radiusVector.y * cos(angle) + radiusVector.x * sin(angle));
	coordinates = center + newRadiusVector;

	// No need for customizable rotation around own center: it is the same for all Simple Shapes
	this->angle += angle;
}

void SimpleShape::setParameter(const std::string& name, const std::string& value) {
	if (name == "x") {
		coordinates.x = atof(value.c_str());
	} else if (name == "y") {
		coordinates.y = atof(value.c_str());
	} else if (name == "angle") {
		angle = atof(value.c_str());
	} else {
		setSpecificParameter(name, value);
	}
}
