#include <cmath>
#include "Coord2D.hpp"

Coord2D::Coord2D(double x, double y)
: x(x), y(y) {
}

double Coord2D::distanceTo(const Coord2D& coord) const {
	return sqrt((x - coord.x) * (x - coord.x) + (y - coord.y) *  (y - coord.y));
}
