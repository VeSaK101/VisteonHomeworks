#include "Vector2D.hpp"

Vector2D::Vector2D(double x, double y)
: x(x), y(y) {
}

Vector2D::Vector2D(const Coord2D& initial, const Coord2D& terminal)
: Vector2D(terminal.x - initial.x, terminal.y - initial.y) {
}

Vector2D Vector2D::operator -() const {
	return Vector2D(-x, -y);
}

Vector2D Vector2D::operator +(const Vector2D& other) const {
	return Vector2D(x + other.x, y + other.y);
}

Vector2D Vector2D::operator -(const Vector2D& other) const {
	return *this + -other;
}

Vector2D& Vector2D::operator +=(const Vector2D& other) {
	*this = *this + other;
	return *this;
}

Vector2D& Vector2D::operator -=(const Vector2D& other) {
	*this = *this - other;
	return *this;
}

Vector2D& Vector2D::operator *=(double factor) {
	*this = *this * factor;
	return *this;
}

double Vector2D::operator *(const Vector2D& other) const {
	return x * other.x + y * other.y;
}

Vector2D Vector2D::operator *(double factor) const {
	return Vector2D(x * factor, y * factor);
}

Coord2D operator +(const Coord2D& c, const Vector2D& v) {
	return Coord2D(c.x + v.x, c.y + v.y);
}

Coord2D& operator +=(Coord2D& c, const Vector2D& v) {
	c.x += v.x;
	c.y += v.y;
	return c;
}
