#include <Shapes/Group.hpp>
#include <UI/StateMachine.hpp>
#include <memory>
#include "OOPaintApp.hpp"
#include "Canvas.hpp"
#include "Shapes/RegistryFactory.hpp"
#include "LinuxPluginManager.hpp"

const char* TITLE = "Object-Oriented Paint - EA";
const int WIDTH = 640;
const int HEIGHT = 480;
const SDL_Color BACKGROUND_COLOR = {0x30, 0x30, 0x30, 0xff};

int main(int, char* argv[]) {
	std::string cmdLine = argv[0];
	auto pluginDirPath = cmdLine.erase(cmdLine.find_last_of("/\\")) + "/plugins";

	// Create subsystems & wire them together
	RegistryFactory factory;
	auto pluginManager = std::make_shared<LinuxPluginManager>();
	pluginManager->loadPlugins(pluginDirPath, factory);
	Canvas canvas(TITLE, WIDTH, HEIGHT, BACKGROUND_COLOR);
	auto stateMachine = std::make_shared<StateMachine>(canvas, factory);
	OOPaintApp application(canvas, stateMachine);

	application.run();
}
