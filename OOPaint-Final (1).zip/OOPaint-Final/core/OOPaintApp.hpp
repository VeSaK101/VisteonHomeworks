#ifndef OOPAINTAPP_HPP_
#define OOPAINTAPP_HPP_

#include <memory>
#include "Canvas.hpp"
#include "Shapes/Factory.hpp"
#include "UI/StateMachine.hpp"

// FIXME: concrete class, doesn't have abstract base or separate interface
class OOPaintApp {
public:
	OOPaintApp(Canvas& canvas, std::shared_ptr<StateMachine> stateMachine);

	void run();
	
private:
	Canvas& canvas;
	std::shared_ptr<StateMachine> stateMachine;
};

#endif /* OOPAINTAPP_HPP_ */
