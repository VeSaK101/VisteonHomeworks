#include <iostream>
#include <dirent.h>
#include <stdexcept>
#include <dlfcn.h>
#include "LinuxPluginManager.hpp"

LinuxPluginManager::~LinuxPluginManager() {
	for (auto handle : handles) {
		dlclose(handle);
	}
}

void LinuxPluginManager::loadPlugins(const std::string& path, ShapeRegistry& registry) {
	DIR *dir = opendir(path.c_str());
	if (dir == NULL) {
		throw std::runtime_error("Error opening directory " + path);
	}

	while (auto entry = readdir(dir)) {
		std::string fileName = entry->d_name;
		auto handle = dlopen((path + "/" + fileName).c_str(), RTLD_LAZY);
		if (handle != nullptr) {
			std::clog << "Trying to load " << fileName << "...";
			auto entryPoint = reinterpret_cast<void(*)(ShapeRegistry&)> (dlsym(handle, "registerShapeMakers"));
			if (entryPoint != nullptr) {
				std::clog << " ok" << std::endl;
				entryPoint(registry);
			} else {
				std::clog << "Failed!" << std::endl;
			}
		}
	}

	closedir (dir);
}
