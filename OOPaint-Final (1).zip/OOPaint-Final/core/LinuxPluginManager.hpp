#ifndef SRC_LINUXPLUGINMANAGER_HPP_
#define SRC_LINUXPLUGINMANAGER_HPP_

#include <vector>
#include "PluginManager.hpp"

class LinuxPluginManager: public PluginManager {
public:
	~LinuxPluginManager();

	void loadPlugins(const std::string& path, ShapeRegistry& registry);

private:
	std::vector<void*> handles;
};

#endif /* SRC_LINUXPLUGINMANAGER_HPP_ */
