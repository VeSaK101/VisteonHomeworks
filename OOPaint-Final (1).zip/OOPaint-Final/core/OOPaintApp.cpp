#include <cmath>
#include <map>
#include "OOPaintApp.hpp"
#include "Shapes/Group.hpp"

OOPaintApp::OOPaintApp(Canvas& canvas, std::shared_ptr<StateMachine> stateMachine)
: canvas(canvas), stateMachine(stateMachine) {
}

void OOPaintApp::run() {
	// Main event loop
	while (true) {
		SDL_Event event;

		if (SDL_WaitEvent(&event))
		{
			if (event.type == SDL_QUIT) {
					return;
			}

			stateMachine->onEvent(event);

			canvas.update();
		}
	}
}
