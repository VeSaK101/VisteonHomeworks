#ifndef SRC_MOVINGSTATE_HPP_
#define SRC_MOVINGSTATE_HPP_

#include "Shapes/Factory.hpp"
#include "State.hpp"

class MovingState: public State {
public:
	MovingState(Canvas& canvas, Factory& factory, std::shared_ptr<Shape> currentShape);
	void onMouseBtnDown(const SDL_MouseButtonEvent& event) override;
	void onKeyDown(const SDL_KeyboardEvent& event) override;
	void onMouseMotion(const SDL_MouseMotionEvent& event) override;
	void onMouseWheel(const SDL_MouseWheelEvent& event) override;

private:
	Factory& factory;
	std::shared_ptr<Shape> currentShape;
};

#endif /* SRC_MOVINGSTATE_HPP_ */
