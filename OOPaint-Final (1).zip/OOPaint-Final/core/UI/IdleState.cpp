#include "IdleState.hpp"
#include "GroupingState.hpp"
#include "MovingState.hpp"

IdleState::IdleState(Canvas& canvas, Factory& factory)
: State(canvas), factory(factory) {
}

void IdleState::onMouseBtnDown(const SDL_MouseButtonEvent& event) {
	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	Coord2D mouseCoords(mouseX, mouseY);
	auto shape = canvas.getShapeAt(mouseCoords);
	switch (event.button) {
		case SDL_BUTTON_LEFT:
			if (shape != nullptr) {
				requestTransition(std::make_shared<MovingState>(canvas, factory, shape));
			}
			break;

		case SDL_BUTTON_RIGHT:
			if (shape != nullptr) {
				canvas.remove(shape);
			}
			break;
	}
}

void IdleState::onKeyDown(const SDL_KeyboardEvent& event) {
	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	Coord2D mouseCoords(mouseX, mouseY);
	std::shared_ptr<Shape> shape;

	switch (event.keysym.sym) {
	case SDLK_LCTRL:
		requestTransition(std::make_shared<GroupingState>(canvas, factory));
		break;

	case 'c':
		shape = factory.createShape("circle", {{"radius", "50"}});		// FIXME: hardcoded
		shape->setParameter("x", std::to_string(mouseCoords.x));
		shape->setParameter("y", std::to_string(mouseCoords.y));
		shape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded
		canvas.add(shape);

		requestTransition(std::make_shared<MovingState>(canvas, factory, shape));
		break;

	case 'r':
		shape = factory.createShape("rectangle", {{"width", "100"}, {"height", "50"}});		// FIXME: hardcoded
		shape->setParameter("x", std::to_string(mouseCoords.x));
		shape->setParameter("y", std::to_string(mouseCoords.y));
		shape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded, duplicated
		canvas.add(shape);

		requestTransition(std::make_shared<MovingState>(canvas, factory, shape));
		break;
	}
}
