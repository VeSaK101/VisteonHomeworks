#include "MovingState.hpp"
#include "IdleState.hpp"

MovingState::MovingState(Canvas& canvas, Factory& factory, std::shared_ptr<Shape> currentShape)
: State(canvas), factory(factory), currentShape(currentShape) {
}

void MovingState::onMouseBtnDown(const SDL_MouseButtonEvent& event) {
	if (event.button == SDL_BUTTON_LEFT) {
		canvas.add(currentShape);
		requestTransition(std::make_shared<IdleState>(canvas, factory));
	}
}

void MovingState::onKeyDown(const SDL_KeyboardEvent& event) {
	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	Coord2D mouseCoords(mouseX, mouseY);
	switch (event.keysym.sym) {
		case ' ':
			currentShape->rotate(M_PI/4, mouseCoords);
			break;

		case SDLK_ESCAPE:	// ESC
			canvas.remove(currentShape);
			requestTransition(std::make_shared<IdleState>(canvas, factory));
			break;
	}
}

void MovingState::onMouseMotion(const SDL_MouseMotionEvent& event) {
	currentShape->moveBy(Vector2D(event.xrel, event.yrel));
}

void MovingState::onMouseWheel(const SDL_MouseWheelEvent& event) {
	// Moving state
	double factor = 1;
	if (event.y > 0) {
		factor = 1.1;
	}

	if (event.y < 0) {
		factor = 0.9;
	}

	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	currentShape->resize(factor, Coord2D(mouseX, mouseY));
}
