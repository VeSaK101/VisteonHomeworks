#ifndef SRC_UISTATEMACHINE_HPP_
#define SRC_UISTATEMACHINE_HPP_

#include <memory>

#include "Shapes/Factory.hpp"
#include "State.hpp"
#include "Canvas.hpp"

class StateMachine {
public:
	StateMachine(Canvas& canvas, Factory& factory);

	void onEvent(const SDL_Event& event);

private:
	Canvas& canvas;
	Factory& factory;
	std::shared_ptr<State> currentState;
};

#endif /* SRC_UISTATEMACHINE_HPP_ */
