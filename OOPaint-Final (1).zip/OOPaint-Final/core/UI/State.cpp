/*
 * UIState.cpp
 *
 *  Created on: Jul 5, 2017
 *      Author: student
 */

#include "State.hpp"

State::State(Canvas& canvas): canvas(canvas) {
}

void State::onQuitRequest() {
}

void State::onMouseBtnDown(const SDL_MouseButtonEvent&) {
}

void State::onMouseBtnUp(const SDL_MouseButtonEvent&) {
}

void State::onKeyDown(const SDL_KeyboardEvent&) {
}

void State::onKeyUp(const SDL_KeyboardEvent&) {
}

void State::onMouseMotion(const SDL_MouseMotionEvent&) {
}

void State::onMouseWheel(const SDL_MouseWheelEvent&) {
}

std::shared_ptr<State> State::transitionRequested() const {
	return requestedTransition;
}

void State::requestTransition(std::shared_ptr<State> nextState) {
	requestedTransition = nextState;
}

void State::onEnter() {
}

void State::onExit() {
}
