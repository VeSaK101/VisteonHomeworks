#include "GroupingState.hpp"

#include "Shapes/Group.hpp"
#include "IdleState.hpp"

GroupingState::GroupingState(Canvas& canvas, Factory& factory)
: State(canvas), factory(factory), group(std::make_shared<Group>()) {
}

void GroupingState::onMouseBtnDown(const SDL_MouseButtonEvent& event) {
	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	Coord2D mouseCoords(mouseX, mouseY);

	switch(event.button) {
		case SDL_BUTTON_LEFT:
		{
			auto shape = canvas.getShapeAt(mouseCoords);
			if (nullptr != shape) {
				canvas.remove(shape);
				group->add(shape);
			}
		}
			break;
	}
}

void GroupingState::onKeyUp(const SDL_KeyboardEvent& event) {
	if (event.keysym.sym == SDLK_LCTRL) {
		canvas.add(group);
		requestTransition(std::make_shared<IdleState>(canvas, factory));
	}
}
