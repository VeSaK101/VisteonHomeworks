#ifndef SRC_IDLESTATE_HPP_
#define SRC_IDLESTATE_HPP_

#include "Shapes/Factory.hpp"
#include "State.hpp"

class IdleState: public State {
public:
	IdleState(Canvas& canvas, Factory& factory);
	void onMouseBtnDown(const SDL_MouseButtonEvent& event) override;
	void onKeyDown(const SDL_KeyboardEvent& event) override;

private:
	Factory& factory;
};

#endif /* SRC_IDLESTATE_HPP_ */
