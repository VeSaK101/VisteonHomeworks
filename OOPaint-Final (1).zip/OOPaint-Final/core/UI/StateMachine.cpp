#include "StateMachine.hpp"
#include "IdleState.hpp"

StateMachine::StateMachine(Canvas& canvas, Factory& factory)
: canvas(canvas), factory(factory), currentState(std::make_shared<IdleState>(canvas, factory)) {
}

void StateMachine::onEvent(const SDL_Event& event) {
	switch (event.type) {
		case  SDL_QUIT:
			currentState->onQuitRequest();
			break;

		case SDL_MOUSEBUTTONDOWN:
			currentState->onMouseBtnDown(event.button);
			break;

		case SDL_MOUSEBUTTONUP:
			currentState->onMouseBtnUp(event.button);
			break;

		case SDL_KEYDOWN:
			currentState->onKeyDown(event.key);
			break;

		case SDL_KEYUP:
			currentState->onKeyUp(event.key);
			break;

		case SDL_MOUSEMOTION:
			currentState->onMouseMotion(event.motion);
			break;

		case SDL_MOUSEWHEEL:
			currentState->onMouseWheel(event.wheel);
			break;

		default:
			;	// Unknown mouse event, no processing
	}

	if (auto transitionRequest = currentState->transitionRequested()) {
		currentState = transitionRequest;
	}
}
