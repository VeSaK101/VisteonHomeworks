#ifndef SRC_UISTATE_HPP_
#define SRC_UISTATE_HPP_

#include <memory>
#include <SDL2/SDL.h>
#include "Canvas.hpp"

class State {
public:
	State(Canvas& canvas);
	virtual ~State() = default;

	// Events
	virtual void onEnter();
	virtual void onExit();
	virtual void onQuitRequest();
	virtual void onMouseBtnDown(const SDL_MouseButtonEvent& event);
	virtual void onMouseBtnUp(const SDL_MouseButtonEvent& event);
	virtual void onKeyDown(const SDL_KeyboardEvent& event);
	virtual void onKeyUp(const SDL_KeyboardEvent& event);
	virtual void onMouseMotion(const SDL_MouseMotionEvent& event);
	virtual void onMouseWheel(const SDL_MouseWheelEvent& event);

	std::shared_ptr<State> transitionRequested() const;

protected:
	Canvas& canvas;
	void requestTransition(std::shared_ptr<State> nextState);

private:
	std::shared_ptr<State> requestedTransition;
};

#endif /* SRC_UISTATE_HPP_ */
