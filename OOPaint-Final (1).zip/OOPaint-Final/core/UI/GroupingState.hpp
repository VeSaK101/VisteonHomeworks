#ifndef SRC_GROUPINGSTATE_HPP_
#define SRC_GROUPINGSTATE_HPP_

#include <memory>

#include "Shapes/Factory.hpp"
#include "Shapes/Group.hpp"
#include "State.hpp"

class GroupingState: public State {
public:
	GroupingState(Canvas& canvas, Factory& factory);
	void onMouseBtnDown(const SDL_MouseButtonEvent& event) override;
	void onKeyUp(const SDL_KeyboardEvent& event) override;

private:
	Factory& factory;
	std::shared_ptr<Group> group;
};

#endif /* SRC_GROUPINGSTATE_HPP_ */
