#ifndef SRC_PLUGINMANAGER_HPP_
#define SRC_PLUGINMANAGER_HPP_

#include <string>
#include "ShapeRegistry.hpp"

class PluginManager {
public:
	virtual ~PluginManager() {}

	virtual void loadPlugins(const std::string& path, ShapeRegistry& registry) = 0;
};

#endif /* SRC_PLUGINMANAGER_HPP_ */
