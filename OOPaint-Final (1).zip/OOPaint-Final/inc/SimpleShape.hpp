#ifndef SRC_SIMPLESHAPE_HPP_
#define SRC_SIMPLESHAPE_HPP_

#include "Shape.hpp"

class SimpleShape: public Shape {
public:
	SimpleShape();

	void moveBy(const Vector2D& deltaCoords) override;
	void setColor(const SDL_Color& color) override;
	const SDL_Color& getColor() const;
	void resize(double factor, const Coord2D& center) final override;
	void rotate(double angle, const Coord2D& center) final override;
	void setParameter(const std::string& name, const std::string& value) final override;

protected:
	SDL_Color color;
	Coord2D coordinates;
	double angle;
	virtual void resizeAroundOwnCenter(double factor) = 0;
	virtual void setSpecificParameter(const std::string& name, const std::string& value) = 0;
};

#endif /* SRC_SIMPLESHAPE_HPP_ */
