#ifndef SRC_VECTOR2D_HPP_
#define SRC_VECTOR2D_HPP_

#include "Coord2D.hpp"

class Vector2D {
public:
	Vector2D(const Coord2D& initial = Coord2D(), const Coord2D& terminal = Coord2D());
	Vector2D(double x = 0, double y = 0);

	double x;
	double y;

	Vector2D operator-() const;
	Vector2D operator+(const Vector2D& other) const;
	Vector2D operator-(const Vector2D& other) const;
	Vector2D operator*(double factor) const;
	Vector2D& operator+=(const Vector2D& other);
	Vector2D& operator-=(const Vector2D& other);
	Vector2D& operator*=(double factor);
	double operator*(const Vector2D& other) const;
};

Coord2D operator+(const Coord2D& c, const Vector2D& v);
Coord2D& operator+=(Coord2D& c, const Vector2D& v);

#endif /* SRC_VECTOR2D_HPP_ */
