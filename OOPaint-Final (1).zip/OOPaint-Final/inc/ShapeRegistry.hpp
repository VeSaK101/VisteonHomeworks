#ifndef SRC_SHAPEREGISTRY_HPP_
#define SRC_SHAPEREGISTRY_HPP_

#include <vector>
#include <string>
#include <memory>
#include "Shape.hpp"

typedef std::shared_ptr<Shape>(*ShapeMaker)();

class ShapeRegistry {
public:
	virtual ~ShapeRegistry() = default;

	virtual void registerShapeMaker(ShapeMaker maker, const std::string& name) = 0;
	virtual ShapeMaker getShapeMaker(const std::string& name) const = 0;
};

#endif /* SRC_SHAPEREGISTRY_HPP_ */
