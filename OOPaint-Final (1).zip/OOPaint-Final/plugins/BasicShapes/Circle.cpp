#include <iostream>
#include "Circle.hpp"

Circle::Circle()
:radius(0) {
}

void Circle::draw(SDL_Renderer* renderer) const {
	SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

	// Midpoint algorithm for drawing circle
	int x = radius, y = 0;
	int radiusError = 1-x;

	while(x >= y) {
		SDL_RenderDrawPoint(renderer, x + coordinates.x, y + coordinates.y);
		SDL_RenderDrawPoint(renderer, y + coordinates.x, x + coordinates.y);
		SDL_RenderDrawPoint(renderer, -x + coordinates.x, y + coordinates.y);
		SDL_RenderDrawPoint(renderer, -y + coordinates.x, x + coordinates.y);
		SDL_RenderDrawPoint(renderer, -x + coordinates.x, -y + coordinates.y);
		SDL_RenderDrawPoint(renderer, -y + coordinates.x, -x + coordinates.y);
		SDL_RenderDrawPoint(renderer, x + coordinates.x, -y + coordinates.y);
		SDL_RenderDrawPoint(renderer, y + coordinates.x, -x + coordinates.y);

		y++;

		if(radiusError<0) {
			radiusError+=2*y+1;
		}
		else {
			x--;
			radiusError+=2*(y-x+1);
		}
	}
}

std::shared_ptr<Shape> Circle::clone() const {
	return std::make_shared<Circle>(*this);
}

void Circle::resizeAroundOwnCenter(double factor) {
	radius *= factor;
}

bool Circle::containsCoordinates(const Coord2D& coord) const {
	return (coordinates.distanceTo(coord) <= radius);
}

void Circle::setSpecificParameter(const std::string& name, const std::string& value) {
	if (name == "radius") {
		radius = atof(value.c_str());
	} else {
		std::clog << "Circle: trying to set unknown parameter [" << name << "] to value [" << value << "]" << std::endl;
	}
}
