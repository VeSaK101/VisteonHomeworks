#ifndef RECTANGLE_HPP_
#define RECTANGLE_HPP_

#include <vector>
#include "SimpleShape.hpp"

class Rectangle: public SimpleShape {
public:
	Rectangle();

	void draw(SDL_Renderer* renderer) const;
	bool containsCoordinates(const Coord2D& coord) const;
	std::shared_ptr<Shape> clone() const;
	double width() const;
	double height() const;
	std::vector<Coord2D> getVertices() const;

private:
	Coord2D dimensions;
	void resizeAroundOwnCenter(double factor);
	void setSpecificParameter(const std::string& name, const std::string& value);
};

#endif /* RECTANGLE_HPP_ */
