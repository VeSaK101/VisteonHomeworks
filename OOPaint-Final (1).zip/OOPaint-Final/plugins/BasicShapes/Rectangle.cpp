#include <iostream>
#include "Rectangle.hpp"
#include "Vector2D.hpp"

Rectangle::Rectangle() {
}

bool Rectangle::containsCoordinates(const Coord2D& coord) const {
	// See https://math.stackexchange.com/questions/190111/how-to-check-if-a-point-is-inside-a-rectangle/190373#190373
	auto v = getVertices();
	Vector2D AM(v[0], coord);
	Vector2D AB(v[0], v[1]);
	Vector2D AD(v[0], v[3]);

	return 0 < AM * AB && AM * AB < AB * AB && 0 < AM * AD && AM * AD < AD * AD;
}

void Rectangle::draw(SDL_Renderer* renderer) const {
	auto v = getVertices();

	// Draw
	SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
	SDL_RenderDrawLine(renderer, v[0].x, v[0].y, v[1].x, v[1].y);
	SDL_RenderDrawLine(renderer, v[1].x, v[1].y, v[2].x, v[2].y);
	SDL_RenderDrawLine(renderer, v[2].x, v[2].y, v[3].x, v[3].y);
	SDL_RenderDrawLine(renderer, v[3].x, v[3].y, v[0].x, v[0].y);
}

void Rectangle::resizeAroundOwnCenter(double factor) {
	dimensions.x *= factor;
	dimensions.y *= factor;
}

std::shared_ptr<Shape> Rectangle::clone() const {
	return std::make_shared<Rectangle>(*this);
}

std::vector<Coord2D> Rectangle::getVertices() const {
	// Prepare
	auto x1 = coordinates.x;
	auto y1 = coordinates.y;
	auto sin_angle = sin(angle);
	auto cos_angle = cos(angle);

	// Calculate
	auto x2 = x1 + height() * sin_angle;
	auto y2 = y1 + height() * cos_angle;
	auto x3 = x2 + width() * cos_angle;
	auto y3 = y2 - width() * sin_angle;
	auto x4 = x3 - height() * sin_angle;
	auto y4 = y3 - height() * cos_angle;

	return std::vector<Coord2D>({{x1, y1}, {x2, y2}, {x3, y3}, {x4, y4}});
}

double Rectangle::width() const {
	return dimensions.x;
}

double Rectangle::height() const {
	return dimensions.y;
}

void Rectangle::setSpecificParameter(const std::string& name, const std::string& value) {
	if (name == "width") {
		dimensions.x = atol(value.c_str());
	} else if (name == "height") {
		dimensions.y = atol(value.c_str());
	} else {
		std::clog << "Rectangle: trying to set unknown parameter [" << name << "] to value [" << value << "]" << std::endl;
	}
}
