#ifndef CIRCLE_HPP_
#define CIRCLE_HPP_

#include "SimpleShape.hpp"

class Circle: public SimpleShape
{
public:
	Circle();

	void draw(SDL_Renderer* renderer) const override;
	bool containsCoordinates(const Coord2D& coord) const override;
	std::shared_ptr<Shape> clone() const override;

private:
	double radius;
	void resizeAroundOwnCenter(double factor) override;
	void setSpecificParameter(const std::string& name, const std::string& value) override;
};

#endif /* CIRCLE_H_ */
