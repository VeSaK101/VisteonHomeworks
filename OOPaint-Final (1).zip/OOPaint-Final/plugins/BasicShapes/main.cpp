#include <memory>
#include "Circle.hpp"
#include "Rectangle.hpp"
#include "ShapeRegistry.hpp"

std::shared_ptr<Shape> makeCircle() {
	return std::make_shared<Circle>();
}

std::shared_ptr<Shape> makeRectangle() {
	return std::make_shared<Rectangle>();
}

// Entry point
extern "C" void registerShapeMakers(ShapeRegistry& registry) {
	registry.registerShapeMaker(makeRectangle, "rectangle");
	registry.registerShapeMaker(makeCircle, "circle");
}
