/**
  ******************************************************************************
  * @file    GPIO/GPIO_IOToggle/Src/main.c
  * @author  MCD Application Team
  * @version V1.2.1
  * @date    13-March-2015
  * @brief   This example describes how to configure and use GPIOs through
  *          the STM32F4xx HAL API.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal_tim.h"


/** @addtogroup STM32F4xx_HAL_Examples
  * @{
  */

/** @addtogroup ADC_RegularConversion_DMA
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* ADC handler declaration */
ADC_HandleTypeDef    AdcHandle;
/*Timer handler declaration */
TIM_HandleTypeDef    TimHandle;

/* Variable used to get converted value */
__IO uint16_t uhADCxConvertedValue = 0;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void Error_Handler(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */

typedef struct {
GPIO_TypeDef * port;
uint16_t pin;
} MyLED_type;

#define cMaxActiveLeds 8

enum {
    cLED1=0,
    cLED2,
    cLED3,
    cLED4,
    cLED5,
    cLED6,
    cLED7,
    cLED8
};

const MyLED_type ActiveLeds[cMaxActiveLeds] = {
    {GPIOA, GPIO_PIN_3},
    {GPIOA, GPIO_PIN_2},
    {GPIOA, GPIO_PIN_10},
    {GPIOB, GPIO_PIN_3},
    {GPIOB, GPIO_PIN_5},
    {GPIOB, GPIO_PIN_4},
    {GPIOB, GPIO_PIN_10},
    {GPIOA, GPIO_PIN_8}
};



void LedInit(uint8_t LedNum)
{
  GPIO_InitTypeDef  GPIO_InitStruct = {
      0, // Pin will be selected later
      GPIO_MODE_OUTPUT_PP, // LED is output
      GPIO_PULLDOWN, // pull down to help with reverse LED logic
      GPIO_SPEED_FAST,
      0 //not used
  };

  GPIO_InitStruct.Pin = ActiveLeds[LedNum].pin; // set current Pin
  HAL_GPIO_Init(ActiveLeds[LedNum].port, &GPIO_InitStruct); // init the GPIO

  HAL_GPIO_WritePin(ActiveLeds[LedNum].port, ActiveLeds[LedNum].pin, GPIO_PIN_SET);// LED off after init

}




int main(void)
{
  ADC_ChannelConfTypeDef sConfig;
  uint8_t LedInitCount = 0;

  /* STM32F4xx HAL library initialization:
       - Configure the Flash prefetch, instruction and Data caches
       - Configure the Systick to generate an interrupt each 1 msec
       - Set NVIC Group Priority to 4
       - Global MSP (MCU Support Package) initialization
     */
  HAL_Init();

  /* Configure the system clock to 84 MHz */
  SystemClock_Config();

    /* -1- Enable GPIOA Clock (to be able to program the configuration registers) */
  __HAL_RCC_GPIOA_CLK_ENABLE();//enable GPIOA Clock
  __HAL_RCC_GPIOB_CLK_ENABLE();//enable GPIOB Clock


  for (LedInitCount = 0; LedInitCount < cMaxActiveLeds; LedInitCount++)
  {//initialize all LEDs on the board
      LedInit(LedInitCount);
  }

  /* Initialize Timer 2 to serve as a time measurement and call IT when expires */
  TimHandle.Instance = TIM2;
  TimHandle.Channel = HAL_TIM_ACTIVE_CHANNEL_1;
  TimHandle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  TimHandle.Init.CounterMode = TIM_COUNTERMODE_DOWN;
  TimHandle.Init.Period = 625;
  TimHandle.Init.Prescaler = 1741;//~13ms
  TimHandle.Init.RepetitionCounter = 0;

  if(HAL_TIM_Base_Init(&TimHandle) != HAL_OK)
  {
      // Initialization Error
      Error_Handler();
  }

  if(HAL_TIM_Base_Start_IT(&TimHandle) != HAL_OK)
  {
      // Start Error
      Error_Handler();
  }

  /*##-1- Configure the ADC peripheral #######################################*/
  AdcHandle.Instance = ADCx;

  AdcHandle.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV2;
  AdcHandle.Init.Resolution = ADC_RESOLUTION_12B;
  AdcHandle.Init.ScanConvMode = DISABLE;
  AdcHandle.Init.ContinuousConvMode = DISABLE;//Disable continuous conversion
  AdcHandle.Init.DiscontinuousConvMode = DISABLE;
  AdcHandle.Init.NbrOfDiscConversion = 1;
  AdcHandle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  AdcHandle.Init.ExternalTrigConv = ADC_SOFTWARE_START;//Configure SW trigger
  AdcHandle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  AdcHandle.Init.NbrOfConversion = 1;
  AdcHandle.Init.DMAContinuousRequests = ENABLE;
  AdcHandle.Init.EOCSelection = DISABLE;

  if(HAL_ADC_Init(&AdcHandle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /*##-2- Configure ADC regular channel ######################################*/
  sConfig.Channel = ADCx_CHANNEL;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  sConfig.Offset = 0;

  if(HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)
  {
    /* Channel Configuration Error */
    Error_Handler();
  }

  /*##-3- Start the conversion process and enable interrupt ##################*/
  if(HAL_ADC_Start_DMA(&AdcHandle, (uint32_t*)&uhADCxConvertedValue, 1) != HAL_OK)
  {
    // Start Conversation Error
    Error_Handler();
  }

  /* Infinite loop */
  while (1)
  {
  }
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow :
  *            System Clock source            = PLL (HSI)
  *            SYSCLK(Hz)                     = 84000000
  *            HCLK(Hz)                       = 84000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 2
  *            APB2 Prescaler                 = 1
  *            HSI Frequency(Hz)              = 16000000
  *            PLL_M                          = 16
  *            PLL_N                          = 336
  *            PLL_P                          = 4
  *            PLL_Q                          = 7
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale2 mode
  *            Flash Latency(WS)              = 2
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the device is
     clocked below the maximum system frequency, to update the voltage scaling value
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /* Enable HSI Oscillator and activate PLL with HSI as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 0x10;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
static void Error_Handler(void)
{
  while(1)
  {
  }
}

/**
  * @brief  Conversion complete callback in non blocking mode
  * @param  AdcHandle : AdcHandle handle
  * @note   This example shows a simple way to report end of conversion, and
  *         you can add your own implementation.
  * @retval None
  */

//Sync variable to prevent restarting the ADC if it is not finished measuring
static uint8_t u8AdcSync = 0;

//Range of the ambient light
#define cMaxAmbient 4000UL
#define cMinAmbient 50UL

//Range of the LED ON and OFF time in cycles
//maximum cycles ON + OFF
#define cMaxCycles 160
#define cMinLedOn 16UL
#define cMaxLedOn (cMaxCycles - cMinLedOn)

//Holds the current phase durations {ON time;OFF time] in cycles
static uint8_t u8PhaseHolder[2] = {cMaxCycles/2,cMaxCycles/2};

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* AdcHandle)
{
    uint32_t u32Product;
    uint16_t u16Divisor;
    uint16_t u16Quotient;

//Calculate the LED ON and LED OFF times based on the ADC measurement.
    if(cMinAmbient >= uhADCxConvertedValue)
    {
        u8PhaseHolder[0] = cMinLedOn;
    }
    else if(cMaxAmbient <= uhADCxConvertedValue)
    {
        u8PhaseHolder[0] = cMaxLedOn;
    }
    else
    {//Linear approximation

    // Step 1
        u32Product = (uint32_t) (cMaxLedOn - cMinLedOn);
    // Step 2
        u32Product = ((uint32_t) (uhADCxConvertedValue - cMinAmbient)) * u32Product;
    // Step 3
        u16Divisor = (uint16_t)(cMaxAmbient - cMinAmbient);
    // Step 4
        u16Quotient = (uint16_t) (u32Product / ((uint32_t) u16Divisor));
    // Rounding the Quotient
        if ((2ul * ((uint32_t) (u32Product % ((uint32_t) u16Divisor)))) >= (uint32_t) u16Divisor)
        {
            u16Quotient ++;
        }
        u8PhaseHolder[0] = (uint16_t)(cMinLedOn + u16Quotient);
    }

    u8PhaseHolder[1] = cMaxCycles - u8PhaseHolder[0];

    u8AdcSync = 1;// ADC measurement is complete
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    static uint32_t u32PhaseCounter = 0;//Counts the duration of the current phase from its start to the current moment
    static uint16_t u16CurrentCount = 0;//holds the current LED to be processed
    static uint16_t u16CurrantPhase = 0;//holds the current LED phase {ON or OFF}


    if((u32PhaseCounter >= u8PhaseHolder[u16CurrantPhase%2]) && (cMaxActiveLeds <= u16CurrentCount))
    {//Phase should be changed
        u16CurrentCount = 0;
        u32PhaseCounter = 0;
        u16CurrantPhase++;
    }


    if(( 0 == u32PhaseCounter%2) && (cMaxActiveLeds > u16CurrentCount))
    {//Change the LED state every 2nd timer time (~26ms)
        HAL_GPIO_WritePin(ActiveLeds[u16CurrentCount].port, ActiveLeds[u16CurrentCount].pin, u16CurrantPhase%2);
        u16CurrentCount++;
    }

    u32PhaseCounter++;//Count the current phase duration


    if(1 == u8AdcSync)
    {// If the ADC is measured start it again for next measurement
        u8AdcSync = 0;

        HAL_ADC_Stop_DMA(&AdcHandle);//SDC cannot be started if it is currently running, So stop it first

        if(HAL_ADC_Start_DMA(&AdcHandle, (uint32_t*)&uhADCxConvertedValue, 1) != HAL_OK) //Start DMA for another measurement.
        {
        // Start Conversation Error
        Error_Handler();
        }
    }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
