/*
 * NoMovement.cpp
 *
 *  Created on: Feb 4, 2019
 *      Author: developer
 */

#include "NoMovement.hpp"

Coord2D NoMovement::calculateNewCoords(const Coord2D& currentCoords,
		const Coord2D&) {
	return currentCoords;
}
