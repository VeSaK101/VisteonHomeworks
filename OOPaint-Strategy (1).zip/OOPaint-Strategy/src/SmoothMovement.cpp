/*
 * SmoothMovement.cpp
 *
 *  Created on: Feb 4, 2019
 *      Author: developer
 */

#include "SmoothMovement.hpp"

Coord2D SmoothMovement::calculateNewCoords(const Coord2D& currentCoords,
		const Coord2D& delta) {
	return currentCoords + delta;
}
