#ifndef SHAPE_HPP_
#define SHAPE_HPP_

#include <memory>
#include <SDL2/SDL.h>
#include "Coord2D.hpp"
#include "Movement.hpp"

class Shape {
public:
	Shape(const Coord2D& coordinates);
	virtual ~Shape() = default;

	virtual void setColor(const SDL_Color& color);
	virtual void moveBy(const Coord2D& delta);
	virtual void draw(SDL_Renderer* renderer) const = 0;
	virtual void resize(double factor) = 0;
	virtual bool containsCoordinates(const Coord2D& coord) const = 0;
	void setMovement(std::shared_ptr<Movement> movement);

protected:
	SDL_Color color;
	Coord2D coordinates;

private:
	std::shared_ptr<Movement> movement;
};

#endif /* SHAPE_HPP_ */
