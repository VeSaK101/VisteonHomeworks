/*
 * SnapMovement.cpp
 *
 *  Created on: Feb 4, 2019
 *      Author: developer
 */

#include "SnapMovement.hpp"

SnapMovement::SnapMovement(int gridSize): gridSize(gridSize) {
}

Coord2D SnapMovement::calculateNewCoords(const Coord2D& currentCoords,
		const Coord2D& delta) {
	auto desired = currentCoords + delta + remainder;
	auto snapCoords = (desired / gridSize) * gridSize;
	remainder = desired - snapCoords;
	return snapCoords;
}
