/*
 * SmoothMovement.hpp
 *
 *  Created on: Feb 4, 2019
 *      Author: developer
 */

#ifndef SRC_SMOOTHMOVEMENT_HPP_
#define SRC_SMOOTHMOVEMENT_HPP_

#include "Movement.hpp"

class SmoothMovement: public Movement {
public:
	Coord2D calculateNewCoords(const Coord2D& currentCoords, const Coord2D& delta) override;
};

#endif /* SRC_SMOOTHMOVEMENT_HPP_ */
