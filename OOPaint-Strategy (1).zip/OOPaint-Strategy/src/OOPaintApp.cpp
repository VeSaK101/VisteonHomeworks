#include <memory>

#include "OOPaintApp.hpp"
#include "Rectangle.hpp"
#include "Circle.hpp"
#include "SmoothMovement.hpp"
#include "SnapMovement.hpp"

OOPaintApp::OOPaintApp(std::shared_ptr<Canvas> canvas)
: canvas(canvas) {
}

void OOPaintApp::run() {
	// Event loop
	std::shared_ptr<Shape> currentShape;

	while (true) {
		SDL_Event event;

		if (SDL_WaitEvent(&event))
		{
			/*
			 * Look for input events and take corresponding actions
			 * 
			 * FIXME: this is a BAD, nasty switch-case which will be beaten 
			 * by OOP design patterns (i.e. State pattern)
			 */
			int x, y;
			SDL_GetMouseState(&x, &y);
			Coord2D mouseCoords(x, y);
			switch (event.type) {
				case  SDL_QUIT:
					return;

				case SDL_MOUSEBUTTONDOWN:
					switch(event.button.button) {
						case SDL_BUTTON_LEFT:
							if (nullptr != currentShape) {
								// We have a new shape, add it to Canvas
								canvas->add(currentShape);
								currentShape = nullptr;
							}
							else {
								// We are in Idle state - pick a shape, if any
								currentShape = canvas->getShapeAt(mouseCoords);
							}
							break;

						case SDL_BUTTON_RIGHT:
							if (nullptr == currentShape) {	// Delete works only when not moving an object
								auto shapeToRemove = canvas->getShapeAt(mouseCoords);
								canvas->remove(shapeToRemove);
							}
							break;
					}
					break;

				case SDL_KEYUP:
					switch(event.key.keysym.sym) {
						case SDLK_LSHIFT:
							if (currentShape != nullptr) {
								currentShape->setMovement(std::make_shared<SnapMovement>(20));
							}
							break;
					}
					break;

				case SDL_KEYDOWN:
					switch(event.key.keysym.sym) {
						case 'c':
							if (nullptr == currentShape) {
								currentShape = std::make_shared<Circle>(mouseCoords, 50);		// FIXME: hardcoded
								currentShape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded
								currentShape->setMovement(std::make_shared<SnapMovement>(20));
								canvas->add(currentShape);
							}
							break;

						case 'r':
							if (nullptr == currentShape) {
								currentShape = std::make_shared<Rectangle>(mouseCoords, Coord2D(100, 50));		// FIXME: hardcoded
								currentShape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded, duplicated
								currentShape->setMovement(std::make_shared<SnapMovement>(20));
								canvas->add(currentShape);
							}
							break;

						case SDLK_LSHIFT:	// ESC
							if (currentShape != nullptr) {
								currentShape->setMovement(std::make_shared<SmoothMovement>());
							}
							break;

						case SDLK_ESCAPE:	// ESC
							canvas->remove(currentShape);
							currentShape = nullptr;
							break;

						default:
							;
					}
					break;

					case SDL_MOUSEMOTION:
						if (nullptr != currentShape) {
							currentShape->moveBy(Coord2D(event.motion.xrel, event.motion.yrel));
						}
						break;

					case SDL_MOUSEWHEEL:
						if (nullptr != currentShape) {
							double factor = 1;
							if (event.wheel.y > 0) {
								factor = 1.1;
							}

							if (event.wheel.y < 0) {
								factor = 0.9;
							}

							currentShape->resize(factor);
						}
						break;
			}

			// Show the result
			canvas->update();
		}
	}
}
