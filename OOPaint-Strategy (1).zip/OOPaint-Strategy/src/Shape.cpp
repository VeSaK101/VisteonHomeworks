#include "Shape.hpp"
#include "NoMovement.hpp"

Shape::Shape(const Coord2D& coordinates)
: coordinates(coordinates), movement(std::make_shared<NoMovement>()) {
}

void Shape::setColor(const SDL_Color& color) {
	this->color = color;
}

void Shape::moveBy(const Coord2D& deltaCoord) {
//	coordinates += deltaCoord;
	coordinates = movement->calculateNewCoords(coordinates, deltaCoord);
}

void Shape::setMovement(std::shared_ptr<Movement> movement) {
	this->movement = movement;
}
