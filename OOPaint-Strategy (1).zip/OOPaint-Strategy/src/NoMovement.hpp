#ifndef SRC_NOMOVEMENT_HPP_
#define SRC_NOMOVEMENT_HPP_

#include "Movement.hpp"

class NoMovement: public Movement {
public:
	Coord2D calculateNewCoords(const Coord2D& currentCoords, const Coord2D& delta) override;
};

#endif /* SRC_NOMOVEMENT_HPP_ */
