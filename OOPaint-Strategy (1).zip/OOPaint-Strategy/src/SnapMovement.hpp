#ifndef SRC_SNAPMOVEMENT_HPP_
#define SRC_SNAPMOVEMENT_HPP_

#include "Movement.hpp"

class SnapMovement: public Movement {
public:
	SnapMovement(int gridSize);
	Coord2D calculateNewCoords(const Coord2D& currentCoords, const Coord2D& delta) override;

private:
	const int gridSize;
	Coord2D remainder;
};

#endif /* SRC_SNAPMOVEMENT_HPP_ */
