#ifndef SRC_MOVEMENT_HPP_
#define SRC_MOVEMENT_HPP_

#include "Coord2D.hpp"

class Movement {
public:
	virtual ~Movement() = default;
	virtual Coord2D calculateNewCoords(const Coord2D& currentCoords, const Coord2D& delta) = 0;
};

#endif /* SRC_MOVEMENT_HPP_ */
