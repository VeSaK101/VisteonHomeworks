#ifndef CIRCLE_HPP_
#define CIRCLE_HPP_

#include "SimpleShape.hpp"

class Circle: public SimpleShape
{
public:
	Circle(const Coord2D& center, double radius);

	void draw(SDL_Renderer* renderer) const;
	bool containsCoordinates(const Coord2D& coord) const;

private:
	double radius;
	void resizeAroundOwnCenter(double factor) override;
};

#endif /* CIRCLE_H_ */
