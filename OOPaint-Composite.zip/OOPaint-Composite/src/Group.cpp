#include "Group.hpp"

void Group::setColor(const SDL_Color& color) {
	for (auto shape : shapes) {
		shape->setColor(color);
	}
}

void Group::moveBy(const Coord2D& delta) {
	for (auto shape : shapes) {
		shape->moveBy(delta);
	}
}

void Group::draw(SDL_Renderer* renderer) const {
	for (auto shape : shapes) {
		shape->draw(renderer);
	}
}

void Group::resize(double factor, const Coord2D& center) {
	for (auto shape : shapes) {
		shape->resize(factor, center);
	}
}

bool Group::containsCoordinates(const Coord2D& coord) const {
	for (auto shape : shapes) {
		if (shape->containsCoordinates(coord)) {
			return true;
		}
	}
	return false;
}

void Group::add(std::shared_ptr<Shape> shape) {
	shapes.insert(shape);
}

void Group::remove(std::shared_ptr<Shape> shape) {
	shapes.erase(shape);
}
