#ifndef SRC_GROUP_HPP_
#define SRC_GROUP_HPP_

#include <memory>
#include <set>	// For simplicity of add/remove; in practice use std::vector<>
#include "Shape.hpp"

class Group: public Shape {
public:
	void setColor(const SDL_Color& color) override;
	void moveBy(const Coord2D& delta) override;
	void draw(SDL_Renderer* renderer) const override;
	void resize(double factor, const Coord2D& center) override;
	bool containsCoordinates(const Coord2D& coord) const override;

	// Specific for CompositeShape
	void add(std::shared_ptr<Shape> shape);
	void remove(std::shared_ptr<Shape> shape);

private:
	std::set<std::shared_ptr<Shape>> shapes;
};

#endif /* SRC_GROUP_HPP_ */
