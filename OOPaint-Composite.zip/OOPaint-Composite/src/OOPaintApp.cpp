#include "OOPaintApp.hpp"

#include "Rectangle.hpp"
#include "Circle.hpp"
#include "Group.hpp"

OOPaintApp::OOPaintApp(std::shared_ptr<Canvas> canvas)
: canvas(canvas) {
}

void OOPaintApp::run() {
	// Event loop
	std::shared_ptr<Shape> currentShape;
	std::shared_ptr<Group> group;

	while (true) {
		SDL_Event event;

		if (SDL_WaitEvent(&event))
		{
			/*
			 * Look for input events and take corresponding actions
			 * 
			 * FIXME: this is a BAD, nasty switch-case which will be beaten 
			 * by OOP design patterns (i.e. State pattern)
			 */
			int x, y;
			SDL_GetMouseState(&x, &y);
			Coord2D mouseCoords(x, y);
			switch (event.type) {
				case  SDL_QUIT:
					return;

				case SDL_MOUSEBUTTONDOWN:
					switch(event.button.button) {
						case SDL_BUTTON_LEFT:
						{
							if (nullptr != currentShape && nullptr == group) {
								// We are in Drag state, drop the current shape
								canvas->add(currentShape);
								currentShape = nullptr;
							} else if (nullptr == currentShape && nullptr != group) {
								// We are in Grouping state, add shape to group
								auto selectedShape = canvas->getShapeAt(mouseCoords);
								if (nullptr != selectedShape) {
									canvas->remove(selectedShape);
									group->add(selectedShape);
								}
							} else if (nullptr == currentShape && nullptr == group) {
								// We are in Idle state - pick a shape, if any
								currentShape = canvas->getShapeAt(mouseCoords);
							} else {
								// Should never happen
							}
						}
							break;

						case SDL_BUTTON_RIGHT:
							if (nullptr == currentShape) {	// Delete works only when not moving an object
								auto shapeToRemove = canvas->getShapeAt(mouseCoords);
								canvas->remove(shapeToRemove);
							}
							break;
					}
					break;

				case SDL_KEYDOWN:
					switch(event.key.keysym.sym) {
						case 'c':
							if (nullptr == currentShape) {
								currentShape = std::make_shared<Circle>(mouseCoords, 50);		// FIXME: hardcoded
								currentShape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded
								canvas->add(currentShape);
							}
							break;

						case 'r':
							if (nullptr == currentShape) {
								currentShape = std::make_shared<Rectangle>(mouseCoords, Coord2D(100, 50));		// FIXME: hardcoded
								currentShape->setColor({0xff, 0xff, 0xff, 0xff});	// FIXME: hardcoded, duplicated
								canvas->add(currentShape);
							}
							break;

						case SDLK_LCTRL:	// Use Left Control key to group
							if (nullptr == group && nullptr == currentShape) {
								// We are in Idle state
								group = std::make_shared<Group>();
							}
							break;

						case SDLK_ESCAPE:	// ESC
							canvas->remove(currentShape);
							currentShape = nullptr;
							break;

						default:
							;
					}
					break;

					case SDL_KEYUP:
						switch(event.key.keysym.sym) {
							case SDLK_LCTRL:	// Left Control UP - finalize selection
								if (nullptr != group) {
									canvas->add(group);
									group = nullptr;
								}
								break;
						}
						break;

					case SDL_MOUSEMOTION:
						if (nullptr != currentShape) {
							currentShape->moveBy(Coord2D(event.motion.xrel, event.motion.yrel));
						}
						break;

					case SDL_MOUSEWHEEL:
						if (nullptr != currentShape) {
							double factor = 1;
							if (event.wheel.y > 0) {
								factor = 1.1;
							}

							if (event.wheel.y < 0) {
								factor = 0.9;
							}

							currentShape->resize(factor, mouseCoords);
						}
						break;
			}

			// Show the result
			canvas->update();
		}
	}
}
