/*
 * SimpleShape.hpp
 *
 *  Created on: Jul 1, 2017
 *      Author: student
 */

#ifndef SRC_SIMPLESHAPE_HPP_
#define SRC_SIMPLESHAPE_HPP_

#include "Shape.hpp"

class SimpleShape: public Shape {
public:
	SimpleShape(const Coord2D& coordinates);

	void setColor(const SDL_Color& color) override;
	void moveBy(const Coord2D& deltaCoord) override;
	void resize(double factor, const Coord2D& center) override;

protected:
	SDL_Color color;
	Coord2D coordinates;

private:
	virtual void resizeAroundOwnCenter(double factor) = 0;
};

#endif /* SRC_SIMPLESHAPE_HPP_ */
