/*
 * SimpleShape.cpp
 *
 *  Created on: Jul 1, 2017
 *      Author: student
 */

#include "SimpleShape.hpp"

SimpleShape::SimpleShape(const Coord2D& coordinates)
: coordinates(coordinates) {
}

void SimpleShape::setColor(const SDL_Color& color) {
	this->color = color;
}

void SimpleShape::moveBy(const Coord2D& deltaCoord) {
	coordinates += deltaCoord;
}

void SimpleShape::resize(double factor, const Coord2D& center) {
	auto radiusVector = coordinates - center;
	auto newRadiusVector = radiusVector * factor;
	coordinates = center + newRadiusVector;
	resizeAroundOwnCenter(factor);	// Template Method Design Pattern
}
