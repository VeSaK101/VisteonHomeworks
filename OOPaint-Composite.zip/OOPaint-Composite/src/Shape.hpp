#ifndef SHAPE_HPP_
#define SHAPE_HPP_

#include <SDL2/SDL.h>
#include "Coord2D.hpp"

class Shape {
public:
	virtual ~Shape() = default;

	virtual void setColor(const SDL_Color& color) = 0;
	virtual void moveBy(const Coord2D& delta) = 0;
	virtual void draw(SDL_Renderer* renderer) const = 0;
	virtual void resize(double factor, const Coord2D& center) = 0;
	virtual bool containsCoordinates(const Coord2D& coord) const = 0;
};

#endif /* SHAPE_HPP_ */
