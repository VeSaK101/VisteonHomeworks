/**
  ******************************************************************************
  * @file    GPIO/GPIO_IOToggle/Src/main.c
  * @author  MCD Application Team
  * @version V1.2.1
  * @date    13-March-2015
  * @brief   This example describes how to configure and use GPIOs through
  *          the STM32F4xx HAL API.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/** @addtogroup STM32F4xx_HAL_Examples
  * @{
  */

/** @addtogroup GPIO_IOToggle
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static GPIO_InitTypeDef  GPIO_InitStruct;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void Error_Handler(void);

static TaskHandle_t MyTaskHandle[2] = {NULL,NULL};
/* Private functions ---------------------------------------------------------*/

#define Timer2Event 1
void vMyTask( void * pvParameters )
 {
	 for( ;; )
	 {
/*	     BaseType_t waitResult;
	     uint32_t u32ProcessCount;
	     uint32_t u32NotificationValue;

	     waitResult = xTaskNotifyWait(0,Timer2Event,&u32NotificationValue,1000);

	     if((pdPASS == waitResult) && ((Timer2Event&u32NotificationValue) != 0))
         {
*/             HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
/*             u32ProcessCount++;

             if(0 == (u32ProcessCount%2))
             {
                 HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_10);
             }
         }

*/
        /* Insert delay 100 ms */
        vTaskDelay(500);
	 }
}
void vMyTask2( void * pvParameters )
 {
	 for( ;; )
	 {

        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_10);

        /* Insert delay 100 ms */
        vTaskDelay(500);
	 }
 }

 void Timer1_ExpireCallBack( TimerHandle_t pxTimer )
 {
    // Optionally do something if the pxTimer parameter is NULL.
    configASSERT( pxTimer );

    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_8);

}

 void Timer2_ExpireCallBack( TimerHandle_t pxTimer )
 {
    // Optionally do something if the pxTimer parameter is NULL.
    configASSERT( pxTimer );

    xTaskNotify(MyTaskHandle[0],1,eSetBits);

}

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  static uint16_t u16MyTaskParameters;
  uint8_t u8TaskRet;
  TimerHandle_t u32TimerHandler[2];

  HAL_Init();

  /* Configure the system clock to 84 MHz */
  SystemClock_Config();

  /* -1- Enable GPIOA Clock (to be able to program the configuration registers) */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* -2- Configure PA05 IO in output push-pull mode to
         drive external LED */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  u32TimerHandler[0] = xTimerCreate( "Timer1",       // Just a text name, not used by the kernel.
                                          ( 100 ),   // The timer period in ticks.
                                          pdTRUE,        // The timers will auto-reload themselves when they expire.
                                          ( void * ) 1,  // Assign each timer a unique id equal to its array index.
                                         Timer1_ExpireCallBack // Each timer calls the same callback when it expires.
                                     );
  u32TimerHandler[1] = xTimerCreate( "Timer2",       // Just a text name, not used by the kernel.
                                          ( 500 ),   // The timer period in ticks.
                                          pdTRUE,        // The timers will auto-reload themselves when they expire.
                                          ( void * ) 1,  // Assign each timer a unique id equal to its array index.
                                         Timer2_ExpireCallBack // Each timer calls the same callback when it expires.
                                     );

  if( u32TimerHandler[0] == NULL )
  {
      // The timer was not created.
  }
  else
  {
      // Start the timer.
      if( xTimerStart( u32TimerHandler[0], 0 ) != pdPASS )
      {
          // The timer could not be set into the Active state.
      }
  }

  if( u32TimerHandler[1] == NULL )
  {
      // The timer was not created.
  }
  else
  {
      // Start the timer.
      if( xTimerStart( u32TimerHandler[1], 0 ) != pdPASS )
      {
          // The timer could not be set into the Active state.
      }
  }


  u8TaskRet = xTaskCreate( vMyTask, "MyTask", 100, &u16MyTaskParameters, 1, &MyTaskHandle[0] );
  u8TaskRet &= xTaskCreate( vMyTask2, "MyTask2", 100, &u16MyTaskParameters, 1, &MyTaskHandle[1] );
//  xTaskCreate( vMyTask, "MyTask", 100, &u16MyTaskParameters, tskIDLE_PRIORITY, &xHandle );

  if (u8TaskRet == pdTRUE) {
    vTaskStartScheduler();  // should never return
  } else {
     // --TODO blink some LEDs to indicate fatal system error
  }

  while (1)
  {

  }
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow :
  *            System Clock source            = PLL (HSI)
  *            SYSCLK(Hz)                     = 84000000
  *            HCLK(Hz)                       = 84000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 2
  *            APB2 Prescaler                 = 1
  *            HSI Frequency(Hz)              = 16000000
  *            PLL_M                          = 16
  *            PLL_N                          = 336
  *            PLL_P                          = 4
  *            PLL_Q                          = 7
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale2 mode
  *            Flash Latency(WS)              = 2
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the device is
     clocked below the maximum system frequency, to update the voltage scaling value
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /* Enable HSI Oscillator and activate PLL with HSI as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 0x10;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
static void Error_Handler(void)
{
  while(1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
